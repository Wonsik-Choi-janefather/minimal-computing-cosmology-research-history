# WRRA Neuropsychology v0.10 — Bilingual release

Wonsik Choi · 22 October 2026

Complete Korean manuscript: 205 pages. Complete English manuscript: 189 pages. Each has twelve parts and 54 chapters. The new consciousness extension is Chapters 45–53; the previous synthesis is Chapter 54. Appendix A12 explains the Core 2.1 structural/inheritance extension while preserving the earlier Core 1.0 explanation and computations. Additional references W3–W5 and R71–R89 credit original concepts and research. Philosophical extension questions are distinguished from established neuropsychological evidence.

The English extension was translated after assembly of the initial Korean v0.10 package. Earlier package notes describing English v0.9 record that earlier assembly stage. This bilingual release includes both complete v0.10 manuscripts. Existing tables and Chapters 41–42/Appendix D were preserved. No new consciousness simulation, neural-data analysis, clinical trial, external peer review, or Astra review was performed.

Zenodo version DOI: 10.5281/zenodo.23552653 (reserved before publication). GitBook: https://independent-research.gitbook.io/wrra-neuropsychology/ . GitHub: https://github.com/Wonsik-Choi-janefather/minimal-computing-cosmology-research-history/tree/main/books/wrra-neuropsychology . Publication status is recorded separately after verification.
